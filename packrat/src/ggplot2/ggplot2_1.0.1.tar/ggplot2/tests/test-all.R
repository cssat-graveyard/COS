library(testthat)
library(ggplot2)

test_package("ggplot2")
