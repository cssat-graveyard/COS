library(testthat)
library(plyr)

test_check("plyr")
